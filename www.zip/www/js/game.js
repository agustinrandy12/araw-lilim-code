var ai1,ai2,ai3,ai4,ai5,ai6;
var sun,cloud1,cloud2;
var player;
var keyboard;
var playbutton, pausebutton,resumebutton,retrybutton,btn;
var pause;
var gameOverText,scoreText,bestText,score = 0;
var left,right,up,down;
var bgaudio,soundEffects,soundEffectsOut;	
var game = new Phaser.Game(800, 600, Phaser.CANVAS, '');

game.state.add("bootGame",bootGame);
game.state.add("preloadGame",preloadGame);
game.state.add("menuGame",menuGame);
game.state.add("playGame",playGame);
game.state.add("winGame",winGame);
game.state.add("loseGame",loseGame);
game.state.start("bootGame");