bootGame = 
	{
		create:function () 
			{
				game.physics.startSystem(Phaser.Physics.ARCADE);
				keyboard = game.input.keyboard.createCursorKeys();
				game.state.start("preloadGame");
			},  		
  	}