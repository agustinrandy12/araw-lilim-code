playGame = 
	{
		create:function()
			{

				bg = game.add.image(0,0,"playground");
				
				player = game.add.sprite(500,500,"dude");
	            player.scale.x = 1;
	            player.scale.y = 1;

	            ai1 = game.add.sprite(Math.random()*800,Math.random()*600,"enemyAI")
	            player.scale.x = 1;
	            player.scale.y = 1;
	            
	            ai2 = game.add.sprite(Math.random()*800,Math.random()*600,"enemyAI2")
	            ai2.scale.x = 1;
	            ai2.scale.y = 1;

	            ai3 = game.add.sprite(Math.random()*800,Math.random()*600,"enemyAI3")
	            ai3.scale.x = 1;
	            ai3.scale.y = 1;
	            
	            ai4 = game.add.sprite(Math.random()*800,Math.random()*600,"enemyAI4")
	            ai4.scale.x = 1;
	            ai4.scale.y = 1;
	            
	            ai5 = game.add.sprite(Math.random()*800,Math.random()*600,"enemyAI5")
	            ai5.scale.x = 1;
	            ai5.scale.y = 1;

				cloud1 = game.add.tileSprite(0,
	            (game.height - game.cache.getImage("ulap1").height)-550,
	            game.width,
	            game.cache.getImage("ulap1").height,
	            'ulap1');

	            cloud2 = game.add.tileSprite(0,
	            (game.height - game.cache.getImage("ulap2").height)-500,
	            game.width,
	            game.cache.getImage("ulap2").height,
	            'ulap2');
	            
	            sun = game.add.image(-100,-150,"araw");
	            sun.scale.x = 1;
	            sun.scale.y = 1;

	            player.animations.add('walk-left', [6,7,8,9,10,11],9, true);
	            player.animations.add('walk-right', [18,19,20,21,22,23],9, true);
	            player.animations.add('walk-up', [0,1,2,3,4,5],9, true);
	            player.animations.add('walk-down', [12,13,14,15],9, true);

	            ai1.animations.add('left', [9,10,11,12],9, true);
	            ai1.animations.add('right', [24,25,26,27],9, true);
	            ai1.animations.add('up', [1,2,3,4,5],9, true);
	            ai1.animations.add('down', [18,19,20,21],9, true);

	            ai2.animations.add('left', [9,10,11,12],9, true);
	            ai2.animations.add('right', [24,25,26,27],9, true);
	            ai2.animations.add('up', [1,2,3,4,5],9, true);
	            ai2.animations.add('down', [18,19,20,21],9, true);

	            ai3.animations.add('left', [9,10,11,12],9, true);
	            ai3.animations.add('right', [24,25,26,27],9, true);
	            ai3.animations.add('up', [1,2,3,4,5],9, true);
	            ai3.animations.add('down', [18,19,20,21],9, true);

	            ai4.animations.add('left', [5,6,7,8,9],9, true);
	            ai4.animations.add('right',[16,17,18,19],9, true);
	            ai4.animations.add('up', [0,1,2,3,4],9, true);
	            ai4.animations.add('down', [12,13,14,15],9, true);

	            ai5.animations.add('left', [5,6,7,8,9],9, true);
	            ai5.animations.add('right',[16,17,18,19],9, true);
	            ai5.animations.add('up', [0,1,2,3,4],9, true);
	            ai5.animations.add('down', [12,13,14,15],9, true);

	            game.physics.arcade.enable(player);
	            player.body.collideWorldBounds = true;

	            game.physics.arcade.enable(ai1);
    			ai1.body.immovable = true;
    			ai1.body.collideWorldBounds = true;

    			game.physics.arcade.enable(ai2);
    			ai2.body.immovable = true;
    			ai2.body.collideWorldBounds = true;

    			game.physics.arcade.enable(ai3);
    			ai3.body.immovable = true;
    			ai3.body.collideWorldBounds = true;

    			game.physics.arcade.enable(ai4);
				ai4.body.collideWorldBounds = true;

				game.physics.arcade.enable(ai5);
    			ai5.body.immovable = true;
    			ai5.body.collideWorldBounds = true;

	            gameOverText = game.add.text(270,300, '', { fontSize: '800px', fill: 'cyan' ,});
	           	gameOverText.fixedToCamera = true;

	            btn = game.add.button(130,520,"right");
	            btn.scale.y = .5;
	            btn.scale.x = .5;
	            btn.anchor.setTo(0.5, 0.5);
	            btn.fixedToCamera = true;
	            btn.events.onInputDown.add(function(){right=true;});
	            btn.events.onInputUp.add(function(){right=false;});    

	            btn = game.add.button(50,520,"left");
	            btn.scale.x = .5;
	            btn.scale.y = .5;
	            btn.anchor.setTo(0.5, 0.5);
	            btn.fixedToCamera = true;
	            btn.events.onInputDown.add(function(){left=true;});
	            btn.events.onInputUp.add(function(){left=false;});

	            btn = game.add.button(70,460,"up");
	            btn.scale.x = .5;
	            btn.scale.y = .5;
	            btn.events.onInputDown.add(function(){up=true;});
	            btn.events.onInputUp.add(function(){up=false;});

	            btn = game.add.button(70,530,"down");
	            btn.scale.x = .5;
	            btn.scale.y = .5;
	            btn.events.onInputDown.add(function(){down=true;});
	            btn.events.onInputUp.add(function(){down=false;});

	            btn = game.add.button(100,20,"restartbutton",playGame.retry);
	            btn.scale.x = .5;
	            btn.scale.y = .5;

	            scoreText = game.add.text(680, 40,'Score : ',{fontSize: '12', fill: 'cyan' });
	            bestText = game.add.text(680, 16, 'BEST: ' +  playGame.getData() ,{ fontSize: '32px', fill: 'red' });
				
				game.input.onDown.add(playGame.unpause, self);
	            btn = game.add.button(1,-9,"pausebutton",playGame.pause);
	            btn.scale.x = .23;
	            btn.scale.y = .23;

	            bgaudio = game.add.audio("bgmusic");
	            bgaudio.play();
	            playGame.audio(30000);
	          
	            soundEffects = game.add.audio("soundeffects")
	            soundEffectsOut = game.add.audio("soundeffectsout")


			},

		update:function()
			{
				game.physics.arcade.overlap(player,ai1,playGame.killAI1);
		        game.physics.arcade.overlap(player,ai2,playGame.killAI2);
		        game.physics.arcade.overlap(player,ai3,loseGame.killPlayer);
		        game.physics.arcade.overlap(player,ai4,loseGame.killPlayer);
		       	game.physics.arcade.overlap(player,ai5,playGame.killAI2);
		        	if (left) 
				    	{ 
			                player.body.velocity.x=-100;
			                player.animations.play('walk-left');

			                ai1.animations.play('left');
			                ai1.body.velocity.x=-100;

			              	ai2.animations.play('right');
			                ai2.body.velocity.x=100;

			                ai3.animations.play('down');
			                ai3.body.velocity.y=100;

			                ai4.animations.play('up');
			                ai4.body.velocity.y=-100;

			                ai5.animations.play('up');
			                ai5.body.velocity.y=-100;
			             
			    		}
			  
		            else if (right) 
			            {
			                player.body.velocity.x=100;
			                player.animations.play('walk-right');

			                ai1.animations.play('up');
			                ai1.body.velocity.y=-100;

			              	ai2.animations.play('down');
			                ai2.body.velocity.y=100;

			                ai3.animations.play('right');
			                ai3.body.velocity.x=100;

			                ai4.animations.play('left');
			                ai4.body.velocity.x=-100;

			                ai5.animations.play('down');
			                ai5.body.velocity.y=100;
			            
			    		}
			   		else if (up) 
			            {
			                player.body.velocity.y=-100;
			                player.animations.play('walk-up');

			                ai1.animations.play('right');
			                ai1.body.velocity.x=100;

			              	ai2.animations.play('left');
			                ai2.body.velocity.x=-100;

			                ai3.animations.play('up');
			                ai3.body.velocity.y=-100;

			                ai4.animations.play('right');
			                ai4.body.velocity.x=100;

			                ai5.animations.play('right');
			                ai5.body.velocity.x=100;
			    		}

		    		else if (down)
			    		{
			    			player.body.velocity.y = 100;
			    			player.animations.play('walk-down');
			    		
			    			ai1.animations.play('down');
			                ai1.body.velocity.y=100;

			              	ai2.animations.play('up');
			                ai2.body.velocity.y=-100;

			                ai3.animations.play('left');
			                ai3.body.velocity.x=-100;

			                ai4.animations.play('down');
			                ai4.body.velocity.y=100;

			                ai5.animations.play('left');
			                ai5.body.velocity.x=-100;
			    		}
		            
		            else 
			            {
			                player.body.velocity.x = 0;
				            player.body.velocity.y = 0;
				            player.animations.stop();
				            player.frame = 13;
				            ai1.frame = 16;
				            ai2.frame = 16;
				            ai3.frame = 16;
				            ai4.frame = 16;
				            ai5.frame = 16;    
			           	} 
			           	cloud1.tilePosition.x +=0.3;
	                	cloud2.tilePosition.x +=0.6;
	              
			},
			
		savedata:function(score)
			{
    			localStorage.setItem('gamedata',score);
			},
		getData:function() 
			{
    			return(localStorage.getItem('gamedata')==null||localStorage.getItem('gamedata')=='')? 0: localStorage.getItem('gamedata');
			},
			
		
		killAI1:function (player,ai1)
			{
				ai1.kill();
				soundEffects.play();
			    if(playGame.getData()<=score)
				    {
	        			playGame.savedata(score);
	       				bestText.text = 'Best:' + score;
	   				}
    				
        		score += 1;
    			scoreText.text = 'Score:' + score;

    			if(score == 2)
    				{
    					game.state.start("winGame");
    				}
			},
		killAI2:function (player,ai2)
			{
				soundEffects.play();
			    ai2.kill();
			    soundEffects.play();
			    if(playGame.getData()<=score)
				    {
	        			playGame.savedata(score);
	       				bestText.text = 'Best:' + score;
	   				}
    				
        		score += 1;
    			scoreText.text = 'Score:' + score;

    			if(score == 2)
    				{
    					game.state.start("winGame");
    				}
			},
			
	    pause : function()
	     	{
	    		game._paused = true;
			},
    	unpause: function ()
    		{
		  		game._paused = false;
		  	},
		
		retry:function()
		    {
		      	game.state.start("playGame");
		    },
		audio : function(time)
			{
    			setInterval(function()
    				{
       					bgaudio.play();
        			},time)
    		}
  }
