menuGame = 
	{
		create:function () 
			{
			bg = game.add.image(0,0,"playground");
			btn = game.add.button(320,230,"start",menuGame.play);
            btn.scale.x = 1;
            btn.scale.y = 1;
			},
		update:function () 
			{
			},
		play:function()
		    {
		      game.state.start("playGame");
		    },	
	}
