loseGame = 
	{	
    	

    	create : function() 
	    	{
	    			gameOverText = game.add.text(270,300, '', { fontSize: '800px', fill: 'cyan' ,});
	           		gameOverText.fixedToCamera = true;
	       	 		soundEffectsOut = game.add.audio("soundeffectsout")
	    	},
	    update : function() 
    		{

    		},

		killPlayer:function (player,ai3)
			{
				soundEffectsOut.play();
			    player.kill();
			    game._paused = true;
			    gameOverText.text = "Opps you tag the wrong player!!\nSorry Try again next time!!";
			    game.add.image(270,200, "gameover")
			    game.add.button(300,500,"retrybutton",playGame.retry);  
			},

	}