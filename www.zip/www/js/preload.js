preloadGame = 
	{
		preload:function() 
			{
                		game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
                                game.scale.pageAlignHorizontally = true;
                                game.scale.pageAlignVertically = true;

                                game.load.image("araw","img/sun.png")
                                game.load.image("left","img/left.png")
                                game.load.image("right","img/right.png")
                                game.load.image("up","img/up.png")
                                game.load.image("down","img/down.png")
                                game.load.image("ulap1", "img/cloud1.png");
                                game.load.image("ulap2", "img/cloud2.png");
                                game.load.image("playground","img/playground.png")
                                game.load.image("start","img/play.png");
                                game.load.image("pausebutton","img/Pause.png");
                                game.load.image("restartbutton","img/restart.png");
                                game.load.image('retrybutton', 'img/Retry.png');
                                game.load.image('gameover', 'img/GameOver.png');                              
                                game.load.spritesheet("dude","img/player.png",36,62);
                                game.load.spritesheet("enemyAI","img/player2 (2).png",34,62);
                                game.load.spritesheet("enemyAI2","img/player3 (2).png",33,62);
                                game.load.spritesheet("enemyAI3","img/player2shadow.png",34,62);
                                game.load.spritesheet("enemyAI4","img/plyayer3shadow.png",33,62);
                                game.load.spritesheet("enemyAI5","img/player3 (2).png",33,62);
                                game.load.spritesheet("enemyAI6","img/plyayer3shadow.png",33,62);
                                game.load.audio("bgmusic", "audio/bgmusic (2).mp3");
                                game.load.audio("soundeffects", "audio/soundeffect.mp3")
                                game.load.audio("soundeffectsout", "audio/die1.wav")

			},

			create:function()
				{
					game.state.start("menuGame");

				},
	}