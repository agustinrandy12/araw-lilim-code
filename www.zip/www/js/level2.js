level2 = 
	{
		create:function()
			{

			bg = game.add.image(0,0,"playground");

			cloud1 = game.add.tileSprite(0,
            (game.height - game.cache.getImage("ulap1").height)-550,
            game.width,
            game.cache.getImage("ulap1").height,
            'ulap1');

            cloud2 = game.add.tileSprite(0,
            (game.height - game.cache.getImage("ulap2").height)-500,
            game.width,
            game.cache.getImage("ulap2").height,
            'ulap2');

            player = game.add.sprite(500,500,"dude");
            player.scale.x = 1;
            player.scale.y = 1;

            diamond = game.add.group();
            diamond.enableBody = true;
            level2.createDiamond(20000);
            diamond.scale.x = 1;
            diamond.scale.y = 1;

			diamond2 = game.add.group();
            diamond2.enableBody = true;
            level2.createDiamond2(20000);

            enemy= game.add.group();
            enemy.enableBody = true;
            level2.createEnemyS(20000);
            enemy.scale.x = 1;
            enemy.scale.y = 1;

            enemy2 = game.add.group();
            enemy2.enableBody = true;
            level2.createEnemy2S(20000);
            enemy2.scale.x = 1;
            enemy2.scale.y = 1;


            sun = game.add.image(-100,-150,"araw");
            sun.scale.x = 1;
            sun.scale.y = 1;

            player.animations.add('walk-left', [6,7,8,9,10,11],9, true);
            player.animations.add('walk-right', [18,19,20,21,22],9, true);
            player.animations.add('walk-up', [0,1,2,3,4,5],9, true);
            player.animations.add('walk-down', [12,13,14,15,16,17],9, true);

            game.physics.arcade.enable(player);
            player.body.collideWorldBounds = true;

            gameOverText = game.add.text(270,300, '', { fontSize: '800px', fill: 'cyan' ,});
           	gameOverText.fixedToCamera = true;

            btn = game.add.button(100,500,"right",level2.goRight);
            btn.scale.y = .5;
            btn.scale.x = .5;

            btn = game.add.button(30,500,"left",level2.goLeft);
            btn.scale.x = .5;
            btn.scale.y = .5;

            btn = game.add.button(70,460,"up",level2.goUp);
            btn.scale.x = .5;
            btn.scale.y = .5;

            btn = game.add.button(70,530,"down",level2.goDown);
            btn.scale.x = .5;
            btn.scale.y = .5;


            btn = game.add.button(160,20,"restartbutton",level2.retry);
            btn.scale.x = .5;
            btn.scale.y = .5;



            btn = game.add.button(30,20,"playbutton",level2.play);
            btn.scale.x = .2;
            btn.scale.y = .2;

            scoreText = game.add.text(680, 40,'Score : ',{fontSize: '12', fill: 'cyan' });
            bestText = game.add.text(680, 16, 'BEST: ' +  level2.getData() ,{ fontSize: '32px', fill: 'red' });
			
			game.input.onDown.add(level2.unpause, self);
            btn = game.add.button(65,-9,"pausebutton",level2.pause);
            btn.scale.x = .23;
            btn.scale.y = .23;

			},

			update:function()
				{
					game.physics.arcade.collide(diamond,player);
		            game.physics.arcade.collide(diamond2,player);
		            game.physics.arcade.collide(diamond,diamond2);
		            game.physics.arcade.overlap(player,diamond,level2.killDiamond);
		            game.physics.arcade.overlap(player,diamond2,level2.killDiamond);
		            game.physics.arcade.overlap(player,enemy,level2.killPlayer);
		            game.physics.arcade.overlap(player,enemy2,level2.killPlayer);

					if(keyboard.left.isDown)
	                {
	                    player.animations.play('walk-left');
	                    player.body.velocity.x = -100;
	                    
	                }
	            else if(keyboard.right.isDown)
	                {
	                    player.animations.play('walk-right');
	                    player.body.velocity.x = 100;
	                }
	            else if(keyboard.up.isDown)
	                {
	                	player.animations.play('walk-up');
	                    player.body.velocity.y = -100;
	                }
	            else if(keyboard.down.isDown)
	                {
	                	player.animations.play('walk-down');
	                    player.body.velocity.y = 100;
	                }
	            else
	                {
	                    player.body.velocity.x = 0;
	                    player.body.velocity.y = 0;
	                    player.animations.stop();
	                    player.frame = 12;

	                }
	                cloud1.tilePosition.x +=0.3;
	                cloud2.tilePosition.x +=0.6;    
	               
				},

	                
	                // player.body.velocity.x = 0;
	                // player.body.velocity.y = 0;
	                // player.animations.stop();
	                // player.frame = 12;

	              
	                // cloud1.tilePosition.x +=0.3;
	                // cloud2.tilePosition.x +=0.6;    
	               
			
				savedata:function(score)
				 {
    				localStorage.setItem('gamedata',score);
				 },
				getData:function() 
						{
    				return(localStorage.getItem('gamedata')==null||localStorage.getItem('gamedata')=='')? 0: localStorage.getItem('gamedata');
						},

				createDiamond:function(time)
				     {
				      setInterval(function()
				      {
				        diamonds = diamond.create(Math.random()*800,Math.random()*100,"diamond");
				        diamond.scale.y =1;
				        diamond.scale.x =1;

				      },time);
				     
				    },
			    createDiamond2:function(time)
			        {
			          setInterval(function()
			          {
			            diamonds2 = diamond2.create(Math.random()*800,Math.random()*500,"diamond2");
			            diamond2.scale.y =1;
			            diamond2.scale.x =1;

			         },time);
			        },
			    createEnemyS:function(time)
				     {
				      setInterval(function()
				      {
				        enemyShaded = enemy.create(Math.random()*800,Math.random()*100,"enemyshade");
				        enemy.scale.y =1;
				        enemy.scale.x =1;

				      },time);
				     
				    },
				    createEnemy2S:function(time)
				     {
				      setInterval(function()
				      {
				        enemy2Shaded = enemy2.create(Math.random()*800,Math.random()*100,"enemyshade2");
				        enemy2.scale.y =1;
				        enemy2.scale.x =1;

				      },time);
				     
				    },
			    killPlayer:function (player,diamond2)
			        {
			          player.kill();
			          game._paused = true;
			          gameOverText.text = "Opps you tag the wrong player!!\nSorry Try again next time!!";
			          game.add.image(270,200, "gameover")
			          game.add.button(30,20,"retrybutton",level2.retry);
			          
			        },

			 
			    killDiamond:function (player,diamond)
			      {
			        diamond.kill();
			        if(level2.getData()<=score)
			        {
        				level2.savedata(score);
       					bestText.text = 'Best:' + score;

   				 	}
    				else{
        				console.log('x');
   						 }
        				score += 5;
    				scoreText.text = 'Score:' + score;

    				if(score == 40)
    				{
    					game.state.start("level3");
    				}
			       
			      },
			    killDiamonds:function (player,diamonds)
			      {
			        diamonds.kill();
			   
			      },
			    play:function(event)
			      {
			        btn.frame = 0;  
			        game._paused = false;
			        console.log("unpaused")
			      },

	     		pause : function()
	     		{
	    		game._paused = true;
	    		console.log("paused")
	    		
				},

    		unpause: function ()
    		{
	       
	  		 game._paused = false;
	  		 console.log("unpause")
	   		 
			},
			    
			audio : function(time)
			    {
			      setInterval(function()
			      {
			        bgaudio.play();
			      },time)
			    },
			retry:function()
		    {
		      game.state.start("level2");
		    },
		    goRight: function()
		    {
		   
     		 player.animations.play("walk-right");
       		 player.body.velocity.x = 1000;
			},

			goLeft:function ()
			{
      		player.animations.play("walk-left");
        	player.body.velocity.x = -1000;
			},
			goUp:function ()
			{
      		player.animations.play("walk-up");
        	player.body.velocity.y = -1000;
			},
			goDown:function ()
			{
      		player.animations.play("walk-down");
        	player.body.velocity.y = 1000;
			}
	}